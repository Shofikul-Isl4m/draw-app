export { default } from "@workspace/ui/postcss.config";

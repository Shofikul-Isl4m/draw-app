const CreateForm = () => {
  return (
    <div>
      Enter
    </div>
  );
}

export default CreateForm;
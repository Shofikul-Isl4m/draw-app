# `@workspace/eslint-config`

Shared eslint configuration for the workspace.

# `@workspace/typescript-config`

Shared typescript configuration for the workspace.
